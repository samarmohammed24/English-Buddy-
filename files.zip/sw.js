const CACHE="english-buddy-v32";
const ASSETS=["./","index.html","manifest.json","icon-192.png","icon-512.png","icon-maskable-512.png"];

self.addEventListener("install",e=>{
e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});

self.addEventListener("activate",e=>{
e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});

/* Network first (so updates arrive), cache as the offline fallback. Audio from other sites is not touched. */
self.addEventListener("fetch",e=>{
const req=e.request;
if(req.method!=="GET")return;
const url=new URL(req.url);
if(url.origin!==location.origin)return;
e.respondWith(
fetch(req).then(res=>{
if(res&&res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy));}
return res;
}).catch(()=>caches.match(req).then(r=>r||caches.match("index.html")))
);
});
